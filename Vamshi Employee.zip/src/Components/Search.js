import React, { useState } from 'react'
import Card from './Card';

function Search({details}) {
    const[searchfield, setSearchfield]=useState('');
    const[searchshow,setSearchshow]=useState(false); 
 
    const filteredPersons = details.filter(
        person => {
          return (
          
            person
            .name
            .toLowerCase()
            .includes(searchfield.toLowerCase())||
            person
           .username
           .toLowerCase()
           .includes(searchfield.toLowerCase())||
            person
            .id   
            .toString()
            .toLowerCase()
            .includes(searchfield.toLowerCase())||
           person
           .email
           .toLowerCase()
           .includes(searchfield.toLowerCase())
          );
        }
        );
         
    const Handlechange=(e)=>{
        setSearchfield(e.target.value);    
 if(e.target.value===""){
    setSearchshow(false);
 } else{
    setSearchshow(true);
 }
    }
    const searchlist=()=>{
        if (searchshow) {
            return (
              <div>
       {filteredPersons.map(person => <Card key={person.id} person={person} />)} 
       
              </div>
            );
          }
    }
    
  return (
    <div className='search'>
      <input type="search" placeholder="Search" onChange={Handlechange}/>
      {searchlist()}
      {filteredPersons.id} ,{filteredPersons.name}
    </div>
   
  )
}
export default Search
