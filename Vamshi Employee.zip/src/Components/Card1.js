import React from 'react';
import { useLocation } from 'react-router-dom';
const Card1=()=> {
  const location=useLocation()
  const{data}=location.state

  return (
    <div>
   
          <table className="table table-striped table-light">
              <thead className='primary'>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Username</th>
                  <th>Email</th>
                </tr>
              </thead>
              <tbody>
            { data.map((e1, id) => (
              <tr>
                <td>{e1.id}</td>
                <td>{e1.name}</td>
                <td>{e1.username}</td>
                <td>{e1.email}</td>
              </tr>
              ))
          }
              </tbody>
            </table>
      </div> 
  );
}
export default Card1;