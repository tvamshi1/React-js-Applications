import React from 'react'
import Navbar from 'react-bootstrap/Navbar';
function Footer() {
  return ( 
   

<div className='footer'>
<Navbar bg="info" variant="dark" id='navbar'>

   <Navbar.Brand href="#home" id='hftext'> © 2023 Copyright:<b>Employee.com</b></Navbar.Brand>
   
    
    
 
 
</Navbar>
</div>
  )
}
export default Footer
