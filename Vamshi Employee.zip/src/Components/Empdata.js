import React, { useEffect, useState } from 'react'
import Header from './Header';
import axios from 'axios'
import "bootstrap/dist/css/bootstrap.min.css";
import Search from './Search';
import Footer from './Footer';
import { Link } from 'react-router-dom';
import DeleteConfirmation from './DeleteConfirmation';
import Toast from 'react-bootstrap/Toast';


function Empdata() {
    const [value, setValue] = useState([]);
    const [view, setView] = useState([]);
    const [i, setI] = useState([]);
    const [e, setE] = useState([]);
    const [id, setId] = useState();
    const [name, setName] = useState();
    const [username, setUsername] = useState();
    const [email, setEmail] = useState();
    const [arr,setArr]=useState([]);
    
 
   
    const [bool,setBool]=useState(false);
    

    const [displayToaster, setDisplayToaster] = useState(false);
    const [displayConfirmationModal, setDisplayConfirmationModal] = useState(false);
    const [deleteMessage, setDeleteMessage] = useState(null);


    useEffect(() => {
        axios.get("https://jsonplaceholder.typicode.com/users")
            .then((response) => {
                setValue(response.data)
            });
    }, [])
    
    const Info = (e) => {
        view.push(e)
        let b = [...view]
        setView(b)

    };

    const Delete = (e, i) => {
      
        setI(i)
        setE(e)
        setDeleteMessage("Are you sure you want to delete the Record?");
        setDisplayConfirmationModal(true);

    }
    const hideConfirmationModal = () => {
        setDisplayConfirmationModal(false);
    };
    const submitDelete = (e, i) => {


        value.splice(i, 1);
        let b = [...value]
        setValue(b);

        setDisplayConfirmationModal(false);
    };


    const Update = (e, i) => {
        setBool(true)
       
            setI(i)
            setE(e)
            setId(e.id)
            setName(e.name)
            setUsername(e.username)
            setEmail(e.email)
            setDisplayToaster(true);
       
      
    }
   
 const ConfirmUpdate=(e)=>{
    setBool(false)
 e.preventDefault()

 setDisplayToaster(false)
 
    value.map((data,i1)=>{
           if(i1==i){
           data.id=id
           data.name=name
          data.username=username
          data.email=email
           }
    })
 }
  
      

    
    
   
 
 
  console.log(arr);
console.log(id);
console.log(name);
console.log(username);
console.log(email);
    return (
        <div>
            <div className='App'>
               <div>
                <Search details={value} />
                </div>
                <table className="table table-striped table-light">
                    <thead className='primary'>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th>Info</th>
                            <th></th>
                            <th></th>

                        </tr>
                    </thead>
                    <tbody>
                        {
                            value.map((e, i) => (

                                <tr key={i}>
                                    <td scope="col">{e.id}</td>
                                    <td scope="col">{e.name}</td>
                                    <td scope="col">{e.username}</td>
                                    <td scope="col">{e.email}</td>
                                    <td>

                                        <Link to='/Card1' state={{ data: view }}> <button onClick={() => Info(e)}>View</button></Link>
                                    </td>
                                    <td><button onClick={() => Delete(e,i)}>Delete</button></td>
                                    <td><button onClick={() => Update(e,i)}>Update</button></td>
                                </tr>
                            )
                            )}
                    </tbody>
                </table>

                <DeleteConfirmation showModal={displayConfirmationModal} confirmModal={submitDelete} hideModal={hideConfirmationModal} i={i} e={e} message={deleteMessage} />
             
<div>
{ bool?
<Toast >

      <Toast.Header>
        
        <strong className="me-auto">Update Record</strong>
        
      </Toast.Header>
      <Toast.Body>
    <form >

    <table className="table table-striped table-light" >
          <thead className='primary'>
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Name</th>
              <th scope="col">Username</th>
              <th scope="col">Email</th>
              <th>Info</th>
            </tr>
          </thead>
          <tbody>
           
               <tr>
                <td scope="col"> <input type="number" placeholder='Id' value={id} onChange={(x)=>setId(x.target.value)} /></td>
                <td scope="col"> <input type="text" placeholder='Name' value={name} onChange={(x)=>setName(x.target.value)}/></td>
                <td scope="col"> <input type="text" placeholder='UserName' value={username} onChange={(x)=>setUsername(x.target.value)}></input></td>
                <td scope="col">  <input type="text" placeholder='Email'   value={email} onChange={(x)=>setEmail(x.target.value)}></input></td>
                <td>
                  <input type="submit" onClick={ConfirmUpdate} value="ConfirmUpdate" />
                </td>

              </tr>


          </tbody>
        </table>


    </form>

      </Toast.Body>
      
    </Toast>
:null}
</div>


               

            </div>
            
        </div>
    )
}
export default Empdata
