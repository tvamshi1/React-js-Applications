import React from 'react'


function Card({person}) {
  return (
    <div>  
    <h3> {person.id} , {person.name} , {person.username} , {person.email} </h3>
    </div>
  )
}

export default Card
