
import './App.css';
import Empdata from './Components/Empdata';
import { BrowserRouter, Route,  Routes, } from 'react-router-dom';   
import Card1 from './Components/Card1';
import Header from './Components/Header';
import Footer from './Components/Footer';

function App() {
  return (
    <div className="App">
      <layout>
      <layout>
          <Header/>
      </layout>
      <layout>
      <BrowserRouter>
      <Routes>
          <Route path='/' element={<Empdata/>}/>
          <Route path='/Card1' element={<Card1/>}/>
      </Routes>
      </BrowserRouter>  
      </layout>
      <layout>
        <Footer/>
        </layout>  
        </layout>
    </div> 
  );
}
export default App;
