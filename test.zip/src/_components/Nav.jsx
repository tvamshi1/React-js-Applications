import { NavLink } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';

import { authActions } from '_store';
import { useState } from 'react';

export { Nav };

function Nav() {
   
    const auth = useSelector(x => x.auth.value);
    const[check,setcheck]=useState([auth])
    console.log(check)
    const dispatch = useDispatch();
    const logout = () => dispatch(authActions.logout())
    // only show nav when logged in
    if (!auth) return null;
    
    return (
        <nav className="navbar navbar-expand navbar-dark bg-dark px-3">
            <div className="navbar-nav">
                
             {(check.role !=="Auditor") ? <div>
             <NavLink to="/home" className="nav-item nav-link">Home</NavLink>
                <NavLink to="/" className="nav-item nav-link">Audit</NavLink>
             <NavLink to="/users" className="nav-item nav-link">Dashboard</NavLink></div>
              :<div>
                <NavLink to="/" className="nav-item nav-link">Home</NavLink>
                <NavLink to="/users" className="nav-item nav-link">Dashboard</NavLink>
                </div>}
                
                <button onClick={logout} className="btn btn-link nav-item nav-link">Logout</button>
            </div>
        </nav>
    );
}