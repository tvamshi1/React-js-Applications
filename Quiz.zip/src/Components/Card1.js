import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';

function Card1() {
  return (
   
    <div className='App'>
    <Card id="Card">
      <Card.Header><h1>Welcome To Quiz</h1></Card.Header>
      <Card.Body>
        <Card.Title></Card.Title>
        <Card.Text>
         <img src='image.jpg' width={1100} height={300}></img>
        </Card.Text>
       <Link to='/Quiz'> <Button variant="success" id='button'><b>StartQuiz</b></Button></Link>
      </Card.Body>
    </Card>
    </div>
  );
}

export default Card1;