import React, { useEffect, useState } from 'react'
import { questions } from './Questions'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';

function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [counter, setCounter] = useState(1200);
  const [counterrun, setCounterrun] = useState('');
  const [bool, setBool] = useState(true);
  const [bool1, setBool1] = useState(false);
  const [bool2, setBool2] = useState(true);
  const [attempt, setAttempt] = useState(0);
  const [bool3, setBool3] = useState(true)
   const [prev, setPrev] = useState(true)

  //  const [currAnswer,setCurrAnswer]=useState();
  const [answer, setAnswer] = useState([]);
  const [active, setActive] = useState(false);
  // const [arr, setarr] = useState([]);
   const [selectedAnswerIndex, setSelectedAnswerIndex] = useState()


  
   
  const handleClickButton = (isCorrect,answerText,index,currentQuestion) => {
    let b = questions[currentQuestion].answerIndex
  b.push(index)
    setSelectedAnswerIndex(index)
    console.log(selectedAnswerIndex);
   console.log(b)
  console.log(answerText)
    if (isCorrect) {
      setScore(score + 1);
    }
    if (isCorrect || !isCorrect) {
      setAttempt(attempt + 1);
    }
  }

  const handleClickNext = (isCorrect) => {

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
      setBool(true);
    }
    if (nextQuestion == 1) {
      setBool1(true)
    }
    if (nextQuestion == 3) {
      setBool2(false)
    }
  setPrev(false)
  };
  const prevQuestion = currentQuestion - 1;
  const handleClickPrev = (isCorrect) => {
   
    if (prevQuestion >= 0) {
      setCurrentQuestion(prevQuestion);
      setBool(true);
    }
    if (prevQuestion == 0) {
      setBool1(false)
    }
    if (prevQuestion < 3) {
      setBool2(true)
    }
     setPrev(false)
      
  }
  const handleSubmit = () => {
    setShowScore(true);
    setBool(false);
    setCounterrun(counter)
  }
  useEffect(() => {
    const _timer = setInterval(() => {
      if (counter == 0) {
        clearInterval(_timer);

        setShowScore(true);
        setBool(false);
        setBool3(false);

      } else {
        setCounter(counter - 1);

      }
    }, 1000);
    return () => clearInterval(_timer);
  },)
  var minutes = Math.floor(counter / 60);

  var seconds = counter - (minutes * 60);

  var minutesrun = Math.floor(counterrun / 60);

  var secondsrun = counterrun - (minutes * 60);
  const addLeadingZero = (number) => (number > 9 ? number : `0${number}`)
  // console.log(answer);
  // let arr = []
  // for(let i in answer){
  //   if(typeof answer[i] == "number"){
  //     // console.log(answer[+i-1]);
  //     arr.push(answer[+i-1])
  //   }
  // }
 

  return (
    <div className="app">
      <Card id="Card">
        <Card.Header>

          <h1>Welcome To Quiz </h1><div id='time'> {bool ? (<h3>Time Left : {addLeadingZero(minutes)}:{addLeadingZero(seconds)}<br /></h3>) : null}
          </div>

        </Card.Header>
        <Card.Body>
          <Card.Title>
          </Card.Title>
          <Card.Text>


            {showScore ? (
              <section className="showScore-section">


                <table class="table">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col">Question Attempted</th>
                      <th scope="col">Correct Answers</th>
                      <th scope="col">Wrong Answers</th>
                      <th scope="col">Total Marks</th>
                      <th scope="col">Obtained Marks</th>
                      <th scope='col'>Time Taken </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td scope="row">{attempt}</td>
                      <td>{score}</td>
                      <td>{attempt - score}</td>
                      <td>8</td>
                      <td>{score * 2}</td>
                      {bool3 ? <td>{1-minutesrun}:{60-secondsrun}</td>
                        : <td>{'02'}:{'00'}</td>}
                    </tr>

                  </tbody>
                </table>
                <p>Thank You !!!!</p>
                <Link to='/Card1'> <Button variant="success" id='button'><b>Restart Quiz</b></Button></Link>
              </section>
            ) : (
              <>
                <section className="question-section">
                  <h3>

                    Question {currentQuestion + 1}/{questions.length}

                  </h3><br></br>
                  <h3>{questions[currentQuestion].questionText}</h3>
                </section>

                <section className="answer-section">
                  {questions[currentQuestion].answerOptions.map((item,index) => {
                  //   <div>
                      // { prev ? <button id="button1" index={index} onClick={() => handleClickButton(item.isCorrect, item.answerText,index)}>
                  //     {item.answerText}
                  //   </button> :
                  //   <button id="button1" 
                  //   //  style={ 
                  // //  {backgroundColor: "Green"} :{ backgroundColor:"rgb(7, 54, 124)" }}
                  //  index={index} onClick={() => handleClickButton(item.isCorrect, item.answerText,index)}>
                  //     {item.answerText}
                  //   </button>}

                  //   </div>
                      return(
                        <div>
                      { prev ? 
                       <button id="button1" index={index} onClick={() => handleClickButton(item.isCorrect, item.answerText,index,currentQuestion)}>
                      {item.answerText}
                    </button> 
                     : <button id="button1"
                    
                    /* //arr.map((data1)=>( */
                         
                      style={ item.answerText== answer?
                   {backgroundColor: "Green"} :{ backgroundColor:"rgb(7, 54, 124)" }}
                   index={index} onClick={() => handleClickButton(item.isCorrect, item.answerText,index)}>
                      {item.answerText} 
                     </button>} 
                    
                    
            
                    </div>
                      )
                      })}

                </section>
                {bool1 ? <button id="next" onClick={() => handleClickPrev(isCorrect)}><b>Prev</b></button> : null}
                {bool2 ? <button id="next" onClick={() => handleClickNext(isCorrect)} ><b>Next</b></button> :
                <button id="next" onClick={() => handleSubmit(isCorrect)} ><b>Submit</b></button>}

              </>
            )}
          </Card.Text>
        </Card.Body>
      </Card>
    </div>
  )
}

export default Quiz
