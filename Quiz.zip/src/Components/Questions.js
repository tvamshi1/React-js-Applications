export const questions = [
    {
      questionText:" Which of the following is used in React.js to increase performance?",
      answerOptions: [
        { answerText: "Virtual DOM", isCorrect: true },
        { answerText: "Real DOM", isCorrect: false },
        { answerText: "Both A & B", isCorrect: false },
        { answerText: "None of the above", isCorrect: false },
      ],
      answerIndex:''
    },
    {
      questionText: "Identify the one which is used to pass data to components from outside?",
      answerOptions: [
        { answerText: "Render with arguments", isCorrect: false },
        { answerText: "setState", isCorrect: false },
        { answerText: "PropTypes", isCorrect: false },
        { answerText: "Props", isCorrect: true },
      ],
      answerIndex:''
    },
    {
      questionText: "What is Babel?",
      answerOptions: [
        { answerText: "Javascript compiler", isCorrect: true },
        { answerText: "Javascript interpreter", isCorrect: false },
        { answerText: "Javascript transpiler", isCorrect: false },
        { answerText: "None of the above", isCorrect: false },
      ],
      answerIndex:''
    },
    {
      questionText: "How many elements can a valid react component return?",
      answerOptions: [
        { answerText: "1", isCorrect: true },
        { answerText: "2", isCorrect: false },
        { answerText: "3", isCorrect: false },
        { answerText: "4", isCorrect: false },
      ],
      answerIndex:''
    },
  ];
  