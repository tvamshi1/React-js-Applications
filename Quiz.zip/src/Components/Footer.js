import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
function Footer() {
  return (
    <div className='footer'>
       <Navbar bg="info" variant="dark" id='navbar'>
       
          <Navbar.Brand href="#home" id='hftext'>@ 2023 Copy Right:<b> www.vamshiquiz.com</b></Navbar.Brand>
          
           
           
        
        
      </Navbar>
    </div>
  )
}

export default Footer
