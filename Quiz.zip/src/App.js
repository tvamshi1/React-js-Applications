
import './App.css';
import Card1 from './Components/Card1';
import Footer from './Components/Footer';
import Header from './Components/Header';
import Quiz from './Components/Quiz';
import { BrowserRouter, Route,  Routes, } from 'react-router-dom'; 

function App() {
  return (


    
    <div className="App" >
      <layout >
        <layout>
          <Header />
        </layout>
        <layout>
         
      <BrowserRouter>
      <Routes>
  
          <Route path='/' element={<Card1/>}/>
          <Route path='/Quiz' element={<Quiz/>}/>
          <Route path='/Card1' element={<Card1/>}/>

          </Routes>
    
      </BrowserRouter> 
  
        </layout>
        <layout>
          <Footer/>
        </layout>
      </layout>
    </div>
  );
}

export default App;
